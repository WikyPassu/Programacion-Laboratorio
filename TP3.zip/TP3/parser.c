#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include "LinkedList.h"
#include "Employee.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromText(FILE* pFile, LinkedList* pArrayListEmployee)
{
    int i, counter = 0, state = 0, flag = 0;
    char id[500], name[500], hoursWorked[500], salary[500];
    Employee* auxEmployee;

    if(pFile != NULL && pArrayListEmployee != NULL)
    {
        printf("Leyendo archivo (modo texto)...\n\n");
        Sleep(800);
        fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", id, name, hoursWorked, salary);
        while(!feof(pFile))
        //while(counter !=5 )
        {
            fscanf(pFile, "%[^,],%[^,],%[^,],%[^\n]\n", id, name, hoursWorked, salary);
            Employee* oneEmployee = employee_newParameters(id, name, hoursWorked, salary);
            for(i=0; i<ll_len(pArrayListEmployee); i++)
            {
                auxEmployee = ll_get(pArrayListEmployee, i);
                if(auxEmployee != NULL)
                {
                    if(auxEmployee->id == oneEmployee->id)
                    {
                        flag = 1;
                        break;
                    }
                }
            }
            if(flag == 0)
            {
                ll_add(pArrayListEmployee, oneEmployee);
                counter++;
            }
            flag = 0;
        }
        fclose(pFile);
        state = 1;
        printf("Empleados cargados al sistema con exito: %d\n\n", counter);
    }
    else
    {
        printf("\nError.\n");
    }

    return state;
}

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromBinary(FILE* pFile, LinkedList* pArrayListEmployee)
{

    return 1;
}
