#ifndef employee_H_INCLUDED
#define employee_H_INCLUDED
typedef struct
{
    int id;
    char name[128];
    int hoursWorked;
    int salary;
}Employee;

Employee* employee_new();
Employee* employee_newParameters(char* idStr, char* nameStr, char* hoursWorkedStr, char* salaryStr);
void employee_delete();

int employee_setId(Employee* this, int id);
int employee_getId(Employee* this, int* id);

int employee_setName(Employee* this, char* name);
int employee_getName(Employee* this, char* name);

int employee_setHoursWorked(Employee* this, int hoursWorked);
int employee_getHoursWorked(Employee* this, int* hoursWorked);

int employee_setSalary(Employee* this, int salary);
int employee_getSalary(Employee* this, int* salary);

int employee_showMenu(int* pOption, char* message, int low, int high);
int employee_verifyCompliance(char* message);

#endif // employee_H_INCLUDED
