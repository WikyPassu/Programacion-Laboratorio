#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Inputs.h"
#include "stringFormat.h"
#include "Utilities.h"
#include "Employee.h"

int employee_showMenu(int* pOption, char* message, int low, int high)
{
    int state = 0;
    if(pOption != NULL)
    {
        state = 1;
        system("cls");
        printf("--------------------------------------------------------------\n");
        printf("%s", message);
        printf("\n--------------------------------------------------------------\n\n");
        getValidInt(pOption, "una opcion", low, high, 0); //Pido un entero valido con rango.
        printf("\n");
    }
    return state;
}

Employee* employee_new()
{
    Employee* oneEmployee;
    oneEmployee = (Employee*) malloc(sizeof(Employee));
    return oneEmployee;
}

Employee* employee_newParameters(char* idStr, char* nameStr, char* hoursWorkedStr, char* salaryStr)
{
    Employee* oneEmployee;
    oneEmployee = employee_new();
    if(oneEmployee != NULL)
    {
        employee_setId(oneEmployee, atoi(idStr));
        employee_setName(oneEmployee, nameStr);
        employee_setHoursWorked(oneEmployee, atoi(hoursWorkedStr));
        employee_setSalary(oneEmployee, atoi(salaryStr));
    }
    else
    {
        printf("\nError.\n");
    }
    return oneEmployee;
}

int employee_setId(Employee* this, int id)
{
    int valid = 0;
    if(this != NULL)
    {
        this->id = id;
        valid = 1;
    }
    else
    {
        printf("\nError.\n");
    }
    return valid;
}

int employee_getId(Employee* this, int* id)
{
    int state = 0;
    if(this != NULL)
    {
        *id = this->id;
        state = 1;
    }
    else
    {
        printf("Error.\n");
    }
    return state;
}

int employee_setName(Employee* this, char* name)
{
    int valid = 0;
    if(this != NULL)
    {
        strcpy(this->name, name);
        valid = 1;
    }
    else
    {
        printf("Error.\n");
    }
    return valid;
}

int employee_getName(Employee* this, char* name)
{
    int state = 0;
    if(this != NULL)
    {
        strcpy(name, this->name);
        state = 1;
    }
    else
    {
        printf("Error.\n");
    }
    return state;
}

int employee_setHoursWorked(Employee* this, int hoursWorked)
{
    int valid = 0;
    if(this != NULL)
    {
        this->hoursWorked = hoursWorked;
        valid = 1;
    }
    else
    {
        printf("\nError.\n");
    }
    return valid;
}

int employee_getHoursWorked(Employee* this, int* hoursWorked)
{
    int state = 0;
    if(this != NULL)
    {
        *hoursWorked = this->hoursWorked;
        state = 1;
    }
    else
    {
        printf("Error.\n");
    }
    return state;
}

int employee_setSalary(Employee* this, int salary)
{
    int valid = 0;
    if(this != NULL)
    {
        this->salary = salary;
        valid = 1;
    }
    else
    {
        printf("Error.\n");
    }
    return valid;
}

int employee_getSalary(Employee* this, int* salary)
{
    int state = 0;
    if(this != NULL)
    {
        *salary = this->salary;
        state = 1;
    }
    else
    {
        printf("Error.\n");
    }
    return state;
}

int employee_verifyCompliance(char* message)
{
    int isSatisfied = 0;
    char answer; //Repuesta del usuario.
    getChar(&answer, message); //Le pido al usuario que ingrese una respuesta.
    if(answer == 's' || answer == 'S')
    {   //Si responde 's' o 'S', esta satisfecho.
        isSatisfied = 1;
    }
    return isSatisfied;
}
